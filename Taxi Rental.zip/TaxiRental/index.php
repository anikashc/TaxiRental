<?php require_once('includes/header.php');?>


<div class="jumbotron">
  <h1 class="display-4">Taxi Rental Application</h1>
  <p class="lead">This is a simple Taxi Rental Application to display use of SQL and its queries</p>
  
  <a class="btn btn-primary btn-lg" href="register.php" role="button">Register</a>
</div>
<?php require_once('includes/footer.php');?>

