<?php

    $con=mysqli_connect('localhost','root','','users');
    if(!$con){
        echo 'Connection Error';
    }

?>