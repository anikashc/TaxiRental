-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2020 at 09:47 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_ID` int(11) NOT NULL,
  `Admin_Name` varchar(100) NOT NULL,
  `Admin_Email` varchar(100) NOT NULL,
  `Admin_Password` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_ID`, `Admin_Name`, `Admin_Email`, `Admin_Password`) VALUES
(1, 'Admin', 'admin@taxirental.com', '5f4dcc3b5aa765d61d8327deb882cf99');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `BookingID` int(11) NOT NULL,
  `User_Email` varchar(100) NOT NULL,
  `Car_Make` varchar(100) NOT NULL,
  `Car_Model` varchar(100) NOT NULL,
  `Amount` int(11) NOT NULL,
  `Date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`BookingID`, `User_Email`, `Car_Make`, `Car_Model`, `Amount`, `Date`) VALUES
(1, 'user1@taxirental.com', 'Ford', 'Fusion', 221, '27/04/2020'),
(2, 'user1@taxirental.com', 'Ford', 'Fusion', 714, '27/04/2020'),
(3, 'user1@taxirental.com', 'Ford', 'Fusion', 238, '27/04/2020'),
(4, 'user1@taxirental.com', 'Ford', 'Fusion', 9639, '27/04/2020'),
(5, 'a@b.com', 'Maruti', 'Swift', 728, '28/04/2020');

-- --------------------------------------------------------

--
-- Table structure for table `taxis`
--

CREATE TABLE `taxis` (
  `ID` int(11) NOT NULL,
  `Car_Make` varchar(100) NOT NULL,
  `Car_Model` varchar(100) NOT NULL,
  `Car_Year` int(11) NOT NULL,
  `Transmission_Type` varchar(100) NOT NULL,
  `Rate_Per_KM` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `taxis`
--

INSERT INTO `taxis` (`ID`, `Car_Make`, `Car_Model`, `Car_Year`, `Transmission_Type`, `Rate_Per_KM`) VALUES
(2, 'Ford', 'Fusion', 2016, 'Auto', 17),
(4, 'Maruti', 'Swift', 2016, 'Auto', 13),
(6, 'Honda', 'Amaze', 2018, 'Auto', 18);

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `ID` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(400) NOT NULL,
  `Date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`ID`, `Name`, `DOB`, `Email`, `Password`, `Date`) VALUES
(4, 'User', '31/11/2020', 'user1@taxirental.com', '$2y$10$vCwDEWcIDy2P3ItMmka8nuWAEbCMxz9pLp0HM3P/m6CQEQU5LQD4a', '21/04/2020'),
(10, 'Rohit', '17/10/2007', 'rohit@example.com', '$2y$10$zg2b939rJMzI1pnywsi.ZeKUDzsb1j0t2P3Y2slmkirJCSkgFPqXe', '22/04/2020'),
(11, 'Hello Me', '31/11/2020', 'a@b.com', '$2y$10$uWYa9MazppctaQX1fz.MX.ABHCDQp0tLg1xCMNs3xtmQt9cbECwqG', '28/04/2020');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`BookingID`);

--
-- Indexes for table `taxis`
--
ALTER TABLE `taxis`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `taxis`
--
ALTER TABLE `taxis`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
